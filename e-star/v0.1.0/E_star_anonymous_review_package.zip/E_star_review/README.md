# 匿名数学审阅材料

本文讨论禁用子集和逆定理中的范围因子 `q−1` 及 `q=4,c=2/3` 的指定同余类极限。正文使用 Lev 与 Roth 的既有定理；组合桥为既有框架的重述，相关 Lean 文件是独立重实现核验，不主张首次形式化。

本包供本地或外部数学审阅，尚未投稿、发表或取得同行评审意见。匿名处理只针对材料中的作者身份；不承诺遮蔽数学主题本身可能透露的研究背景。

## 文件入口

- `E_star_anonymous.pdf`：匿名论文正文。
- `E_star_anonymous.tex`：与 PDF 对应的可编辑源文件。
- `CLAIMS_AND_EVIDENCE.md`：主张、数学依据及辅助机器验证的精确范围。
- `RELATED_WORK.md`：最近相关原文与贡献定位。
- `REVIEW_NOTE.md`：给审阅者的重点问题与限制。
- `PROVENANCE.json`：脚本/形式化源的版本和改动范围。
- `MANIFEST.sha256`：包内权威文件的哈希清单。

## 离线有限复现

需要已有 Python 3.12 或兼容解释器；三个数学检查脚本仅使用标准库。无需联网或安装。

```text
python run_checks.py
```

脚本会在本包的 `results/` 下创建唯一运行子目录，复制检查脚本到该目录再运行，保存退出码、输出和结果 JSON。它不会覆盖包内基线文件。完整运行约十几秒，实际时间依主机而异。成功的范围只是所列有限集合/参数，并不证明外部定理或渐近主张。

`checks/check_finite_lemmas.py` 含增量/有界基/坏中心/参数等有界检查；`check_combinatorial_boundaries.py` 覆盖空表示及构造边界；`check_fresh_proof.py` 为另写的构造、归一化和应用检查。精确覆盖和空窗口分别在输出 JSON 中登记，不能把空范围计为实质命中。

## 可选 Lean 复现

已有并固定 Lean `4.33.0-rc1` 与 Mathlib commit `e4c91783ca8e6a7c693ae624ade32fd22d4e43c1` 的构建缓存后，可运行：

```text
python verify_lean.py --lean <lean绝对路径> --library-path <依赖olean目录列表>
```

依赖目录按当前操作系统的路径分隔符分开；可另传 `--checker <leanchecker绝对路径>` 重放 `EStarDistinct` 模块的新声明。脚本不下载依赖、不升级工具链或改变全局配置。所传缓存版本应由审阅者自行核对。

Lean 的覆盖仅为九条算术声明和完整有限去重桥，不含主逆定理的全部外部输入、概率估计、统一阈值及渐近极限。`evidence/` 中的既有成功记录是历史基线；新运行状态以自己的 `results/lean/summary.json` 为准。导入依赖未由本包独立从零重建。

## 文稿编译

TeX 源需已有 XeLaTeX、ctex/fontspec 与数学宏包。当前排版使用 SimSun、SimHei、Consolas；在其他平台可仅替换字体设置，不更改数学内容。不同发行版的 PDF 字节可变，比较源文件和文本内容时不要要求跨环境 PDF 哈希相同。

本包不包含第三方论文全文，只提供公开来源链接、核读范围及所取版本哈希。工具链缓存、编译中间文件、个人路径、内部会话及提示未打包。
